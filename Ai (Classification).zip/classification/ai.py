# Importing required libraries to view and clean data + A.I. training and testing.
print("Importing libraries...")
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

# Initiating constants that will be used in the program.
print("Loading data...")
rawData = ("data/rawData.csv")
savedData = ("data/savedData.csv")
testData = ("data/testSplit.csv")
dtree = DecisionTreeClassifier(random_state=42)

# Initiating variables that will be used in the program.
goToCleaingMenu = False
goToViewingMenu = False
aiTrained = False

# Loading data from CSV files.
try:
    df = pd.read_csv(savedData)
except:
    try:
        df = pd.read_csv(rawData)
    except:
        print("No files found.")
        exit()
df = df.replace(r"No Info", pd.NA, regex=True)










# Loading target column from saved file, and letting the user choose target column if no file was found.
def setTargetColumn(overwrite):
    global inTarget, df
    if overwrite:
        overwriteCheck = input("\nAre you sure you want to overwrite the target column? (y/n): ")
        if overwriteCheck == "y":
            counter = 0
            for i in df.columns:
                print(counter, "-", i)
                counter += 1
            userTargetChoice = int(input("Choose target column: "))
            inTarget = df.columns[userTargetChoice]
            with open("data/targetColumn.txt", "w") as f:
                f.write(inTarget)
            print("Target column saved.")
        elif overwriteCheck == "n":
            c0=0
    else:
        try:
            with open("data/targetColumn.txt") as f:
                inTarget = f.read() 
        except:
            print("\nNo target column was found.")
            counter = 0
            for i in df.columns:
                print(counter, "-", i)
                counter += 1
            userTargetChoice = int(input("Choose target column: "))
            inTarget = df.columns[userTargetChoice]
            with open("data/targetColumn.txt", "w") as f:
                f.write(inTarget)
            print("Target column saved.")
setTargetColumn(False)


# Function to split the data into train/test.
def splitTrainTest(overwrite):
    global td, testData, df, savedData
    if overwrite:
        createTestSplit = input("Are you sure you want to overwrite the train/test split? (y/n): ")
        if createTestSplit == "y":
            print("How much of the data do you want to keep for testing?")
            createTestSplit = int(float((df.shape[0]/100) * float(input("Choose percentage% (0-100): "))))
            print("Splitting data...")
            td = df.tail(createTestSplit)
            df = df.drop(df.tail(createTestSplit).index)
        elif createTestSplit == "n":
            c0=0
    else:
        try:
            td = pd.read_csv(testData)
        except:
            print("\nNo testing data was found.")
            createTestSplit = input("Do you want to make a train/test split? (y/n): ")
            if createTestSplit == "y":
                print("How much of the data do you want to keep for testing?")
                createTestSplit = int(float((df.shape[0]/100) * float(input("Choose percentage% (0-100): "))))
                print("Splitting data...")
                td = df.tail(createTestSplit)
                df = df.drop(df.tail(createTestSplit).index)
            elif createTestSplit == "n":
                c0=0
splitTrainTest(False)


# Function to train the A.I. on the train data.
def trainAi():
    global dtree, trainData, trainTarget, aiTrained
    print("Training ai...")
    trainTarget = df[inTarget]
    trainData = pd.get_dummies(df.drop(inTarget, axis=1))
    dtree.fit(trainData, trainTarget)
    print("A.I. is trained.")
    aiTrained = True
    input("Press enter to continue...")


# Function to test the A.I. with the test data.
def testAi():
    global dtree, testData, testTarget, aiTrained
    print("Testing ai and accuracy...")
    testTarget = td[inTarget]
    testData = pd.get_dummies(td.drop(inTarget, axis=1))
    testData = testData.reindex(columns=trainData.columns, fill_value=0)
    targetPredict = dtree.predict(testData)
    accuracy = int(accuracy_score(testTarget, targetPredict) * 100)
    print("Accuracy: ", accuracy, "%")
    input("Press enter to continue...")


# Function to set the panda's data frame to the last saved dataset (csv file).
def resetSaved():
    global df, totalCells, totalRows, nullCount, missingPercentage, rowsWithNulls
    print("Resetting...")
    try:
        df = pd.read_csv(savedData)
        df = df.replace(r"\?", pd.NA, regex=True)
        totalCells = df.size
        totalRows = len(df.index)
        nullCount = df.isnull().sum().sum()
        missingPercentage = nullCount/totalCells*100
        rowsWithNulls = df.isnull().any(axis=1).sum()
    except:
        print("\nNo data found, nothing was changed.")
        input("Press enter to continue...")


# Function to set the panda's data frame to the raw/original dataset (csv file).
def resetRaw():
    global df, totalCells, totalRows, nullCount, missingPercentage, rowsWithNulls
    print("Resetting...")
    df = pd.read_csv(rawData)
    df = df.replace(r"No Info", pd.NA, regex=True)
    totalCells = df.size
    totalRows = len(df.index)
    nullCount = df.isnull().sum().sum()
    missingPercentage = nullCount/totalCells*100
    rowsWithNulls = df.isnull().any(axis=1).sum()


# Function to get outlier data (numerical columns only) and replace their values with the mean value of their column.
def getOutliers(df, column):
    df[column] = df[column].astype(float)

    Q1 = df[column].quantile(0.25)
    Q3 = df[column].quantile(0.75)
    IQR = Q3 - Q1
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    outliers = (df[column] < lower_bound) | (df[column] > upper_bound)

    meanVal = int(df[column].mean())
    df.loc[outliers, column] = meanVal
    return df


# Function to delete rows/columns that contain nulls/empty values depending on the direction the user chooses.
def deleteData(dir):
    global df, totalCells, totalRows, nullCount, missingPercentage, fixedNulls, goToCleaingMenu
    tdf = df.copy()
    print("————————————————————")
    if dir == "r":
        tdf = tdf.dropna()
    elif dir == "c":
        tdf = tdf.dropna(axis=1)

    print("\nAfter deletion: ")
    tempTotalCells = tdf.size
    tempTotalRows = len(tdf.index)
    tempNullCount = tdf.isnull().sum().sum()
    tempMissingPercentage = tempNullCount/tempTotalCells*100
    print("Total cells: ", totalCells, "->",tempTotalCells)
    print("Total rows: ", totalRows, "->",tempTotalRows)    
    print("Missing cells: ", nullCount, "->",tempNullCount)
    print("Missing cercentge: ", "%.3f" % missingPercentage, "->", "%.3f" % tempMissingPercentage,)

    print("\n0-Save and exit.")
    print("1-Exit without saving.")
    i = int(input("Choose action: \n"))
    if i == 0:
        df = tdf
        totalCells = tempTotalCells
        totalRows = tempTotalRows
        nullCount = tempNullCount
        missingPercentage = tempMissingPercentage
        fixedNulls = True
    elif i == 1:
        c0=0
    goToCleaingMenu = True


# Function to fill empty cells and values with whatever the user chooses.
def fillNulls(method):
    global df, totalRows, fixedNulls, rowsWithNulls, nullCount, missingPercentage, goToCleaingMenu
    print("————————————————————")

    tdf = df.copy()
    if method == "prev":
        tdf = tdf.bfill()
    elif method == "next":
        tdf = tdf.ffill()
    elif method == "mode":
        tdf = tdf.fillna(tdf.mode().iloc[0])
    elif method == "avg":
        numericColumns = tdf.select_dtypes(include=['number']).columns
        for i in numericColumns:
            tdf[i] = tdf[i].fillna(tdf[i].mean())
    elif method == "max":
        tdf = tdf.fillna(tdf.max())
    elif method == "min":
        tdf = tdf.fillna(tdf.min())

    tempNullCount = tdf.isnull().sum().sum()
    tempMissingPercentage = tempNullCount/totalCells*100
    if nullCount == 0:
        print("\nNo nulls found, no rows were affected.")
    else:
        print("\nAffected rows: ", rowsWithNulls)
        print("Missing cells: ", nullCount, "->",tempNullCount)
        print("Missing cercentge: ", "%.3f" % missingPercentage, "->", "%.3f" % tempMissingPercentage,)

    print("\n0-Save and exit.")
    print("1-Exit without saving.")
    i = int(input("Choose action: \n"))
    if i == 0:
        df = tdf
        rowsWithNulls = 0
        missingPercentage = tempMissingPercentage
        nullCount = tempNullCount
    elif i == 1:
        c0=0
    goToCleaingMenu = True










# Set initial data info and print them to the user.
totalCells = df.size
totalRows = len(df.index)
nullCount = df.isnull().sum().sum()
missingPercentage = nullCount/totalCells*100
rowsWithNulls = df.isnull().any(axis=1).sum()
print("\nData information: ")
print("Total cells: ", totalCells)
print("Total rows: ", totalRows)
print("Missing cells: ", nullCount)
print("Missing percentge: ", "%.3f" % missingPercentage)


# (-Menus and actions-)
# 1-Function to show data information to user.
def viewActions():
    print("————————————————————\n\n(-Viewing and analyzing menu-)\n")
    print("0-Number of columns, rows, and cells.")
    print("1-Number of missing values in each column.")
    print("2-Show first 10 rows of data.")
    print("3-Show statistics (mean, std, min, and quartiles).")
    print("4-Show data types info.")
    print("5-Show outlier data.")
    print("6-Back to the main menu.")
    i = int(input("\nChoose action: "))
    if i == 0:
        shapeList = str(df.shape).split(",")
        print(f"\nColumns: {shapeList[1][1:-1]}", f"\nRows: {shapeList[0][1:-1]}", f"\nCells: {df.size}")
        input("Press enter to continue...")
    elif i == 1:
        print(df.isnull().sum())
        input("Press enter to continue...")
    elif i == 2:
        print(df.head(11))
        input("Press enter to continue...")
    elif i == 3:
        print(df.describe())
        input("Press enter to continue...")
    elif i == 4:
        print(df.info())
        input("Press enter to continue...")
    elif i == 5:
        plt.figure(figsize=(15, 5))
        df.boxplot()
        plt.xticks(rotation=45, ha='right')
        plt.yscale('log')
        plt.show()
        input("Press enter to continue...")
    elif i == 6:
        c0 = 0
    if i != 6:
        viewActions()


# 2-Function to choose how to clean data.
def cleaningActions():
    print("————————————————————\n\n(-Cleaning and managing menu-)\n")
    print("0-Delete all rows with missing values.")
    print("1-Delete all columns with missing values.")
    print("2-Replace all missing values with the previous value.")
    print("3-Replace all missing values with the next value.")
    print("4-Replace all missing values with the mode value (most frequent value).")
    print("5-Replace all missing values with the average value (only works with numerical columns).")
    print("6-Replace all missing values with the max value.")
    print("7-Replace all missing values with the minimum value.")
    print("8-Fix outlier values.")
    print("9-Back to the main menu.")
    i = int(input("\nChoose action: "))
    if i == 0:
        deleteData("r")
    elif i == 1:
        deleteData("c")
    elif i == 2:
        fillNulls("prev")
    elif i == 3:
        fillNulls("next")
    elif i == 4:
        fillNulls("mode")
    elif i == 5:
        fillNulls("avg")
    elif i == 6:
        fillNulls("max")
    elif i == 7:
        fillNulls("min")
    elif i == 8:
        numericColumns = df.select_dtypes(include=['number']).columns
        for i in numericColumns:
            getOutliers(df, i)
        print("Done.")
        input("Press enter to continue...")
    elif i == 9:
        c0=0


# 3-Main menu that branches to the rest of the menus.
while 1:
    if goToCleaingMenu:
        goToCleaingMenu = False
        cleaningActions()
    elif goToViewingMenu:
        goToViewingMenu = False
        viewActions()
    print("————————————————————\n\n(-Main menu-)\n")
    print("0-Save all changes and exit.")
    print("1-View current data analytics.")
    print("2-Clean and manage data.")
    print("3-Reset to last saved data.")
    print("4-Reset to raw data.")
    print("5-Train Ai with train data.")
    print("6-Test Ai with test data.")
    print("7-Overwrite test data.")
    print("8-Overwrite target column.")
    print("9-Exit without saving.")
    i = int(input("\nChoose action: "))
    if i == 0:
        df.to_csv(savedData, index=False)
        td.to_csv(testData, index=False)
        exit()
    elif i == 1:
        viewActions()
    elif i == 2:
        cleaningActions()
    elif i == 3:
        resetSaved()
    elif i == 4:
        resetRaw()
    elif i == 5:
        trainAi()
    elif i == 6:
        if aiTrained:
            testAi()
        else:
            print("Please train A.I. first.")
            input("Press enter to continue...")
    elif i == 7:
        splitTrainTest(True)
    elif i == 8:
        setTargetColumn(True)
    elif i == 9:
        exit()